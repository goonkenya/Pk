import httpx
from pyrogram import Client, filters
from FUNC.usersdb_func import *
from TOOLS.check_all_func import *

# Mapping country codes to Random User API nationalities
country_to_nat = {
    'us': 'us', 'uk': 'gb', 'ca': 'ca', 'au': 'au', 'de': 'de',
    'fr': 'fr', 'in': 'in', 'jp': 'jp', 'cn': 'cn', 'br': 'br',
    # Add more mappings as needed
}

@Client.on_message(filters.command("real", [".", "/"]))
async def cmd_real(client, message):
    try:
        checkall = await check_all_thing(client, message)
        if not checkall[0]:
            return

        role = checkall[1]

        if len(message.text.split()) > 1:
            country_code = message.text.split()[1].lower()
            nat = country_to_nat.get(country_code, 'us')
        else:
            nat = 'us'

        async with httpx.AsyncClient() as http_client:
            # Fetch random user data
            response = await http_client.get(
                f"https://randomuser.me/api/?nat={nat}&inc=name,location,phone",
                timeout=10.0
            )
            
            if response.status_code == 200:
                data = response.json()
                user = data['results'][0]
                
                # Extract data
                name = f"{user['name']['title']} {user['name']['first']} {user['name']['last']}"
                street = f"{user['location']['street']['number']} {user['location']['street']['name']}"
                city = user['location']['city']
                state = user['location']['state']
                country = user['location']['country']
                postcode = user['location']['postcode']
                phone = user['phone']
                
                resp = f"""
<b>🔍 Real User Data Retrieved</b>
━━━━━━━━━━━━━━
🆔 <b>Name:</b> <code>{name}</code>
📍 <b>Address:</b> <code>{street}, {city}</code>
🏙️ <b>City:</b> <code>{city}</code>
🗺️ <b>State:</b> <code>{state}</code>
📮 <b>Postcode:</b> <code>{postcode}</code>
🌍 <b>Country:</b> <code>{country}</code>
📞 <b>Phone:</b> <code>{phone}</code>
━━━━━━━━━━━━━━
<b>Requested by:</b> <a href="tg://user?id={message.from_user.id}">{message.from_user.first_name}</a> [{role}]
"""
                await message.reply_text(resp)
            else:
                await message.reply_text("❌ Failed to fetch user data. Please try again later.")

    except httpx.TimeoutException:
        await message.reply_text("⏳ Request timed out. Please try again.")
    except Exception as e:
        import traceback
        await error_log(traceback.format_exc())
