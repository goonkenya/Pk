from FUNC.defs import *
from FUNC.usersdb_func import *

async def get_charge_resp(result, user_id, fullcc):
    try:
        # If result is a string (maybe error or raw text), handle accordingly
        if isinstance(result, str):
            status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
            response = result
            hits = "NO"

        else:
            # assuming result is requests.Response or compatible object with `.text` or dict-like json

            text = getattr(result, "text", str(result)).lower()

            if (
                "succeeded" in text
                or "thank you" in text
                or "payment complete" in text
                or '"state": "succeeded"' in text
                or '"status": "succeeded"' in text
                or "your payment has already been processed" in text
            ):
                status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
                response = "Payment succeeded"
                hits = "YES"
                await forward_resp(fullcc, "Donation Charge $1", response)

            elif "insufficient_funds" in text:
                status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
                response = "Insufficient Funds"
                hits = "YES"
                await forward_resp(fullcc, "Donation Charge $1", response)

            elif "incorrect_cvc" in text:
                status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
                response = "CCN ❌"
                hits = "YES"
                await forward_resp(fullcc, "Donation Charge $1", response)

            elif "transaction_not_allowed" in text:
                status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
                response = "Purchase Not Supported"
                hits = "YES"
                await forward_resp(fullcc, "Donation Charge $1", response)

            elif "expired_card" in text or "card has expired" in text:
                status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
                response = "Expired Card"
                hits = "NO"

            elif "card was declined" in text or "declined" in text:
                status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
                response = "Card Declined"
                hits = "NO"

            elif "cvc_check" in text and '"pass"' in text:
                status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
                response = "CVV LIVE"
                hits = "YES"
                await forward_resp(fullcc, "Donation Charge $1", response)

            else:
                status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
                response = "Unknown response or failed"
                hits = "NO"

        json_result = {
            "status": status,
            "response": response,
            "hits": hits,
            "fullz": fullcc,
        }
        return json_result

    except Exception as e:
        status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"
        response = f"Error: {e}"
        hits = "NO"

        json_result = {
            "status": status,
            "response": response,
            "hits": hits,
            "fullz": fullcc,
        }
        return json_result
