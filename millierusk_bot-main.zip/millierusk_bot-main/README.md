# millierusk_bot
A Advance CC Checker Bot Based On Python

## To Start
-`edit config.yml`
install requirements.txt - `pip install -r requirements.txt`
- `python -m mills` - if Windows
- `sudo bash start.sh`- if linux
- `python3 -m mills`

## VIDEO TUTORIAL
 - [Telegram](https://t.me/RoldexVerse/33307)

Hello Pros

Roldex This Side From @Roldexverse

lets do it

1. download git first
2. download vs code or any editor
3. download source code "https://github.com/r0ld3x/millierusk_bot"
 now follow me

> git clone https://github.com/r0ld3x/millierusk_bot
 fill config.yml
MONGODB_PASS = ReuSNuqoSiX31Czo

get session string from https://replit.com/@r0ld3x/SynergySession?v=1
#RIP captcha.
#RIP everything
wait until complete



SOURCE CODE:  https://github.com/r0ld3x/millierusk_bot
get  SESSION_STRING from https://replit.com/@r0ld3x/SynergySession?v=1
get API_ID & API_HASH from https://my.telegram.org/

DONE + i will update and fix all errors.
By @Roldexverse

