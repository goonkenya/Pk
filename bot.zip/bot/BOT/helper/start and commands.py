import asyncio
import time
from pyrogram import Client, filters
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from FUNC.defs import *
from FUNC.usersdb_func import *


@Client.on_message(filters.command("start", [".", "/"]))
async def cmd_start(Client, message):
    try:
        text = """<b>
🤖 Bot Status: Active ✅

📢 For announcements and updates, join us 👉 here.

💡 Tip: To use Raven in your group, make sure to set it as an admin.
</b>"""
        
        WELCOME_BUTTON = [
            [
                InlineKeyboardButton("🔎menu", callback_data="cmds")
            ],
            [
                InlineKeyboardButton("Close", callback_data="close")
            ]
        ]
        
        await message.reply_text(text, reply_markup=InlineKeyboardMarkup(WELCOME_BUTTON), parse_mode="html")

    except Exception:
        import traceback
        await error_log(traceback.format_exc())
